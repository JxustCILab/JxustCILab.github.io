clear
clc
format long; 
fprintf('运行DPSPSO算法\n');
%mex cec17_func.cpp -DWINDOWS
%% 预设参数
%w = 0.9;          %惯性权重
%c1 = 1.49445;     %个体学习因子
%c2 = 1.49445;     %社会学习因子
D = 30; %维度
popsize = 100; %种群大小
maxFES = 10000*D; %粒子迭代更新的最大次数
maxGEN = maxFES/popsize; % 每个粒子最大的进化次数 
iwt = 0.9 - (1 : maxGEN) * (0.7 / maxGEN);
c = 1.49445;
number = 51;
results = zeros(30, number);
%%
for problem=1:30
    %% 设置位置边界
%     [lb, ub, opt_f] = Get_Func_Info(D, problem);
%     lu = [lb * ones(1, D); ub * ones(1, D)];
    Xmin = -100;
    Xmax = 100; 
    if problem == 2
        continue;
    end
    %% 运行30次
    for num = 1:number
            rand('seed', sum(100 * clock)); 
            %% 种群初始化
            % Initialize the main population
            %粒子初始位置
            X = repmat(Xmin, popsize, 1) + rand(popsize,D) .* (repmat(0-Xmin, popsize, 1));
            %计算实时适应度
            val_X=zeros(popsize,1);%创建一个n*1全为零的矩阵，实现每个个体适应度的初始化
            for j=1:popsize
                val_X(j)=cec17_func(X(j,:)',problem);%x(j,:)代表了一个个体的位置。
            end
            pBest = X; val_pBest = val_X;  
            %index 存储每个粒子的排名
            [~,sort_index] = sort(val_pBest); %按照适配值从小到大排序，存储排序下标
            for r = 1:popsize
                index(sort_index(r)) = r; % 第i个粒子的排名index(i)
            end 

            [~,indexG] = min(val_pBest); %找到全局最优和其位置
            gBest = pBest(indexG,:); val_gBest = val_pBest(indexG,:);    
            Vmax = (Xmax - Xmin)*0.2;  Vmin = -Vmax;    %规定速度的范围

            % .*点乘表示两个矩阵对应位置元素相乘
            V = repmat(Vmin,popsize,1) + rand(popsize,D).*repmat(Vmax-Vmin,popsize,1);%粒子速度

            % Learning Probability Pc
            t = 0 : 1/(popsize-1):1;
            t = 5.*t;
            Pc = 0.0+(0.5-0.0).*(exp(t)-exp(t(1)))./(exp(t(popsize))-exp(t(1)));

            %动态划分种群 和 学习典范

            tt = 0.5;
            study = popsize * tt;
            explore = popsize * 0.7;
            for i = 1:popsize
                pBest_ind(i,:) = LearnIndex_CLPSO2(val_pBest,popsize,D,i,Pc(i),index,study);% 学习典范下标
            end 
            FES = 0; GEN = 1;  %GEN当前进化代数

        %% 迭代更新速度与位置
        while   FES < maxFES  
            study = popsize * tt + popsize * 0.3 * FES / maxFES;
            explore = popsize * 0.7 + popsize * 0.2 * FES / maxFES;
            for i=1:popsize %每一个粒子都得更新。
                % update exemplar index
                pBest_ind(i,:) = LearnIndex_CLPSO2(val_pBest,popsize,D,i,Pc(i),index,study);%选择新的学习典范
                % Compehensive Learning Strategy       
                for  j=1:D %记录第i个粒子的每个维度将要学习的值
                    pBest_f(i,j) = pBest(pBest_ind(i,j),j);  %pBest_ind(i,j)第i个粒子的第j维度，即要学习对象的第j维度值
                end  

                % 更新速度和位置
                V(i,:) = iwt(GEN)*V(i,:) + c*rand(1,D).*(pBest_f(i,:)-X(i,:));  % update velocity
                %V(i,:) = boundary_repair(V(i,:),Vmin,Vmax,'absorb');   %保证速度不越界
                for j = 1:D
                    if V(i,j) > Vmax
                        V(i,j) = Vmax;
                    end
                    if V(i,j) < Vmin
                        V(i,j) = Vmin;
                    end 
                end
                %获取该粒子的排名
                rank = index(i);
                %CLPSO 容易陷入局部最优解 
                if rank > explore
                    %if该粒子的排名靠后，就初始化该粒子
                    %X(i,:) = (Xmax-Xmin).*rand(1,D)+Xmin;
                        %X(i,:) = X(i,:) + 1.75*c*rand(1,D).*(gBest-X(i,:));
                    % 
                    X(i,:) = X(i,:) + 10*c*rand(1,D).*(pBest_f(i,:)-X(i,:));
                else
                    X(i,:) = X(i,:)+V(i,:);    % update position
                end

                if all(X(i,:)<=Xmax) && all(X(i,:)>=Xmin)  % X(i,:) is feasible
                    val = cec17_func(X(i,:)',problem);
                    val_X(i) = val;
                    FES = FES+1;
                    if val < val_pBest(i)    % update pBest
                        pBest(i,:) = X(i,:);  
                        val_pBest(i) = val;
                    end 
                end 
                %X(i,:) = boundary_repair(X(i,:),Xmin,Xmax,'absorb');   %保证位置不越界
                for j = 1:D
                    if X(i,j) > Xmax
                        X(i,j) = Xmax;
                    end
                    if X(i,j) < Xmin
                        X(i,j) = Xmin;
                    end 
                end
            end
            % 记录全局最优位置
            [~,indexG] = min(val_pBest);
            gBest = pBest(indexG,:); 
            val_gBest = val_pBest(indexG,:);

            %index 存储每个粒子的排名
            [~,sort_index] = sort(val_X); %按照适配值从小到大排序，存储排序下标
            for r = 1:popsize
                index(sort_index(r)) = r; % 第i个粒子的排名index(i)
            end 

            GEN = GEN+1;
            if (GEN == maxGEN) && (FES < maxFES)
                GEN = GEN-1;
            end 
        end
        %% 记录每次运行的最佳适配值
        %results(num) = val_gBest;
        results(problem, num) = val_gBest;
        fprintf('problem=%d num=%d 适配值=%d \n', problem,num,val_gBest);
    end
end

filename = strcat( 'results_D',num2str(D),'_DPSPSO');
results_mean=mean(results,2); % mean(A,2)返回值为该矩阵的各行向量的均值
results_min=min(results,[],2);
results_max=max(results,[],2);
results_std=std(results,0,2);
save(filename,'results_mean','results_min','results_max','results_std');
