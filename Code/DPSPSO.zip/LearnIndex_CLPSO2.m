function  pBest_ind = LearnIndex_CLPSO2(pfit,popsize,D,i,Pci,index,rank)
%  exemplar index

for j = 1:D
    if rand<Pci %&& index(i) >= rank
        ind1 = randi(popsize);
        while ind1==i || index(ind1) > rank, ind1 = randi(popsize);  end
        ind2 = randi(popsize); 
        while ind2==i||ind2==ind1 || index(ind2) > rank, ind2 = randi(popsize);  end
         %在CLPSO中，我们定义适应度值越大越好，
         %这意味着在求解极小化问题时，我们将使用负函数值作为适应度值。
        if pfit(ind1) < pfit(ind2) %随机选择两个粒子作为学习对象
            pBest_ind(j) = ind1;
        else
            pBest_ind(j) = ind2;
        end 
    else
        pBest_ind(j) = i;
    end 
end

if all(pBest_ind==i)    %如果是全是学习自己维度，则随机找一个维度，再随机找一个其他粒子在该维度的pbest学习
    ind = randi(popsize);
    while ind==i || index(ind) > rank, ind = randi(popsize);  end
    pBest_ind(randi(D)) = ind; 
end

